# Apple Pay on the Web Stripe Demo

Live Demo: https://tschaeff.github.io/apple-pay-web-stripe/

Collect payment and address information from your customers using Apple Pay and the Payment Request API (Chrome) by using the Payment Request Button Element.

Documentation:

* Integrate the Stripe [Payment Request Button](https://stripe.com/docs/elements/payment-request-button)
